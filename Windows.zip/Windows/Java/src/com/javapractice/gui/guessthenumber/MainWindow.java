package com.javapractice.gui.guessthenumber;

import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*; import java.awt.event.*;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {
	protected JLabel label;
	protected JTextField textBox;
	protected JButton guessBtn;
	protected LineBorder border = new LineBorder(Color.BLACK);
	
    private void initializeComponent() {    	
    	try {
    		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	
        /* Window Properties */ { this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); this.setTitle("Guess The Number (Windows (Java))"); this.setSize(400, 200); this.getContentPane().setBackground(Color.WHITE); this.getContentPane().setForeground(Color.BLACK); this.setFont(new Font("Segoe UI", Font.PLAIN, 12)); this.setLocationRelativeTo(null); this.setLayout(null); } {
        	label = new JLabel("Your Guess: "); { label.setForeground(this.getContentPane().getForeground()); label.setFont(this.getFont().deriveFont(Font.PLAIN)); label.setBounds(new Rectangle(new Point(30, 30), label.getPreferredSize())); }; this.add(label);
        	textBox = new JTextField(); { textBox.setPreferredSize(new Dimension(40, 20)); textBox.setFont(this.getFont().deriveFont(Font.PLAIN)); textBox.setBounds(new Rectangle(new Point(100, 29), textBox.getPreferredSize())); textBox.setBorder(border); textBox.setForeground(this.getForeground()); }; this.add(textBox);
        	guessBtn = new JButton("Guess"); { guessBtn.setPreferredSize(new Dimension(85, 30)); guessBtn.setBounds(new Rectangle(new Point(280, 115), guessBtn.getPreferredSize())); guessBtn.addActionListener(guessBtn_Click); }; this.add(guessBtn);
        }
    }
    
	public MainWindow() {
		initializeComponent();
	}

    protected ActionListener guessBtn_Click = (ActionEvent e) -> {
    	if (textBox.getText().equals("1114")) {
    		JOptionPane.showMessageDialog(this, "Correct!", "Guess The Number (Windows (Java))", JOptionPane.INFORMATION_MESSAGE);
    		
    		System.exit(0);
    	} else {
    		JOptionPane.showMessageDialog(this, "Incorrect, try again.", "Guess The Number (Windows (Java))", JOptionPane.WARNING_MESSAGE);
    	}
    };
}
