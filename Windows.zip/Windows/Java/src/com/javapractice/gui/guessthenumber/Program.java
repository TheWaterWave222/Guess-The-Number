package com.javapractice.gui.guessthenumber;

public class Program {
    public static void main(String[] args) {
    	(new MainWindow()).setVisible(true);
    }
}
