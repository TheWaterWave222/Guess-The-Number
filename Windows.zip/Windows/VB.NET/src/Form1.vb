﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (TextBox1.Text.Equals("1114")) Then
            MessageBox.Show("Correct!", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)

            Application.Exit()
        Else
            MessageBox.Show("Incorrect, try again.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
End Class
