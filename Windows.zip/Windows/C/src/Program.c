#include "MainWindow.h"

int WINAPI WinMain(HINSTANCE hThisInst, HINSTANCE hPrevInst, LPSTR lpszCMDArgs, int nCMDShow)
{
	Show();
}