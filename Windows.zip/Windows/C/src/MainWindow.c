#include "MainWindow.h"
#include "GameLogic.h"

void InitializeComponent(void)
{
	#pragma region Window
	wc.lpszClassName = szWndClassName;
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(wc.hInstance, IDI_WINLOGO);
	wc.hbrBackground = ((HBRUSH)(COLOR_WINDOW + 1));

	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, L"RegisterClassW failed.\n\nError: 0x1", L"Guess The Number (Windows (C))", MB_ICONERROR);

		PostQuitMessage(EXIT_FAILURE);
	}

	CenterWindow(GetDesktopWindow(), &rect, nWndWidth, nWndHeight);
	hWnd = CreateWindow(szWndClassName, szWndName, dwWndStyle, rect.left, rect.top, nWndWidth, nWndHeight, NULL, NULL, hInst, NULL);

	if (!hWnd)
	{
		MessageBox(NULL, L"CreateWindowW failed.\n\nError: 0x1", L"Guess The Number (Windows (C))", MB_ICONERROR);

		PostQuitMessage(EXIT_FAILURE);
	}
	#pragma endregion 
	#pragma region Controls
	hFont = CreateFont(15, 0, 0, 0, FW_DONTCARE, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Segoe UI");

	label = CreateWindow(L"Static", L"Your Guess: ", dwChildCtlStyle, 30, 30, 70, 15, hWnd, NULL, hInst, NULL);
	textBox = CreateWindow(L"Edit", L"", dwChildCtlStyle | WS_BORDER, 100, 28, 40, 20, hWnd, NULL, hInst, NULL);
	guessBtn = CreateWindow(L"Button", L"Guess", dwChildCtlStyle, 280, 115, 85, 30, hWnd, (HMENU)01, hInst, NULL);

	SendMessage(label, WM_SETFONT, (WPARAM)hFont, TRUE);
	SendMessage(textBox, WM_SETFONT, (WPARAM)hFont, TRUE);
	SendMessage(guessBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
	#pragma endregion
}

void CenterWindow(HWND hWnd, LPRECT pRect, int nWndWidth, int nWndHeight)
{
	if (GetWindowRect(hWnd, pRect))
	{
		pRect->left = ((pRect->right / 2) - (nWndWidth / 2));
		pRect->top = ((pRect->bottom / 2) - (nWndHeight / 2));
	}
	else PostQuitMessage(EXIT_FAILURE);
}

void Show(void)
{
	InitializeComponent();

	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);

	MSG lpMsg;
	while (GetMessage(&lpMsg, NULL, 0, 0))
	{
		TranslateMessage(&lpMsg);
		DispatchMessage(&lpMsg);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wP, LPARAM lP)
{
	switch (uMsg)
	{
		case WM_CREATE:
			break;
		case WM_COMMAND:
		{
			switch (wP)
			{
				case guessBtn_Click:
				{
					StartGame(textBox);
					break;
				}
			}
			break;
		}
		case WM_CTLCOLORSTATIC:
		{
			SetBkMode((HDC)wP, TRANSPARENT);

			return (BOOL)GetStockObject(NULL);
			break;
		}
		case WM_DESTROY:
		{
			PostQuitMessage(EXIT_SUCCESS);
			break;
		}
		default:
		{
			return DefWindowProc(hWnd, uMsg, wP, lP);
			break;
		}
	}
}