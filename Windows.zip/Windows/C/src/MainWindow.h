#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

#pragma comment(linker,"\"/manifestdependency:type='win32' \ name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \ processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#define guessBtn_Click 01

const wchar_t* szWndClassName = L"App=Guess_The_Number_Windows_C",* szWndName = L"Guess The Number (Windows (C))";
int nWndWidth = 400, nWndHeight = 200;
HINSTANCE hInst; HWND hWnd, label, textBox, guessBtn; RECT rect;
WNDCLASS wc; DWORD dwWndStyle = WS_OVERLAPPEDWINDOW, dwChildCtlStyle = WS_CHILD | WS_VISIBLE; HFONT hFont;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void InitializeComponent(void);
void CenterWindow(HWND, LPRECT, int, int);
void Show(void);