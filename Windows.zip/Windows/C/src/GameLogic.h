#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

wchar_t secretNumber[5] = L"1114", userInput[32768];

int ValidateInput(HWND, wchar_t[], wchar_t[]);

void StartGame(HWND textBox)
{
	int isCorrect = ValidateInput(textBox, secretNumber, userInput);

	if (isCorrect == 1)
	{
		MessageBox(NULL, L"Correct!", L"Guess The Number (Windows (C))", MB_ICONASTERISK);

		PostQuitMessage(EXIT_SUCCESS);
	}
	else MessageBox(NULL, L"Incorrect, try again.", L"Guess The Number (Windows (C))", MB_ICONWARNING);
}

int ValidateInput(HWND textBox, wchar_t leftVal[], wchar_t rightVal[])
{
	GetWindowText(textBox, rightVal, 32768);

	if ((wcscmp(leftVal, rightVal)) == 0)
		return 1;
	else
		return 0;
}