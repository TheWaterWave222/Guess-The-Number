import os

class Program:
      secret_number = 1114; user_input = 0
      
      def validate_input(left_val, right_val):
            right_val = int(input("Your Guess: "))
            
            if (right_val == left_val):
                  return True
            else:
                  return False
            
      def start_game(self):
            is_correct = self.validate_input(self.secret_number, self.user_input)
            
            if (is_correct == True):
                  print("\nCorrect!\n")
                  
                  os.system("pause")
            else:
                  print("\nIncorrect, try again.\n")
                  
                  self.start_game(self)      
                  
      def main(self):
            print("Guess The Number (Python)\n")
      
            self.start_game(self)
            
Program.main(Program)