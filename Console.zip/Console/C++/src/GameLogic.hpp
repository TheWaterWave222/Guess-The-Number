#pragma once

#define UNICODE 1

#include <iostream>

#pragma region Macros
#ifdef UNICODE
#define ValidateInput ValidateInputW
#else
#define ValidateInput ValidateInputA
#endif
#pragma endregion

namespace Guess_The_Number_Console_Cxx
{
	class GameLogic
	{
		public: int secretNumber = 1114, userInput = 0;

		#pragma region Functions
		public: bool ValidateInputW(int leftVal, int rightVal)
		{
			std::wcin >> rightVal;

			if (rightVal == leftVal)
				return true;
			else 
				return false;
		}
	
		public: bool ValidateInputA(int leftVal, int rightVal)
		{
			std::cin >> rightVal;

			if (rightVal == leftVal)
				return true;
			else
				return false;
		}
		#pragma endregion
	};
}