#include "GameLogic.hpp"

int StartGame();

int main(int argc, char** argv)
{
	std::wcout << L"Guess The Number (C++)\n\nYour Guess: ";

	StartGame();


	return 0;
}

int StartGame()
{
	using namespace Guess_The_Number_Console_Cxx;

	GameLogic* game = new GameLogic();

	bool isCorrect = game->ValidateInput(game->secretNumber, game->userInput);

	if (isCorrect == true)
	{
		std::wcout << L"\nCorrect!\n\n";

		system("pause");
	}
	else
	{
		std::wcout << L"\nIncorrect, try again.\n\nYour Guess: ";

		StartGame();
	}


	return 0;
}