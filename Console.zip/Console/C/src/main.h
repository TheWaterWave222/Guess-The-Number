﻿#pragma once

#define UNICODE 1

#include <stdio.h>
#include <stdlib.h>

#pragma region Macros
#ifdef UNICODE
#define ValidateInput ValidateInputW
#else
#define ValidateInput ValidateInputA
#endif
#pragma endregion

int secretNumber = 1114, userInput = 0;

#pragma region Functions
int ValidateInputW(int, int);
int ValidateInputA(int, int);
#pragma endregion

void StartGame(void)
{
	int result = ValidateInput(secretNumber, userInput);

	if (result == 1)
	{
		wprintf_s(L"\nCorrect!\n\n");

		system("pause");
	}
	else
	{
		wprintf_s(L"\nIncorrect, try again\n\nYour Guess: ");

		StartGame();
	}
}