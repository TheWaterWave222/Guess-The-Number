#include "main.h"

void main(int argc, char** argv)
{
	wprintf_s(L"Guess The Number (C)\n\nYour Guess: ");

	StartGame();
}

#pragma region Functions
int ValidateInputW(int leftVal, int rightVal)
{
	wscanf_s(L"%d", &rightVal);

	if (rightVal == leftVal)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int ValidateInputA(int leftVal, int rightVal)
{
	scanf_s("%d", &rightVal);

	if (rightVal == leftVal)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
#pragma endregion