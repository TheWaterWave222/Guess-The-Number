﻿using System;

namespace Guess_The_Number_Console_CSharp
{
    public class GameLogic
    {
        public int secretNumber = 1114, userInput = 0;

        public bool ValidateInput(int leftVal, int rightVal)
        {
            rightVal = Convert.ToInt32(Console.ReadLine());

            if (rightVal == leftVal)
                return true;
            else
                return false;
        }
    }
}