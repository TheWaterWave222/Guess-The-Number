﻿using System;

namespace Guess_The_Number_Console_CSharp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Guess The Number (C#)\n\nYour Guess: ");

            (new Program()).StartGame();
        }

        public void StartGame()
        {
            GameLogic game = new GameLogic();

            bool isCorrect = game.ValidateInput(game.secretNumber, game.userInput);

            if (isCorrect)
            {
                Console.Write("\nCorrect!\n\n");

                Console.Write("Press any key to continue . . ."); Console.ReadKey();
            }
            else
            {
                Console.Write("\nIncorrect, try again.\n\nYour Guess: ");

                StartGame();
            }
        }
    }
}