package com.javapractice.console.guessthenumber;

import java.util.Scanner;

public class GameLogic {
      public int secretNumber = 1114, userInput = 0;
      public Scanner keyboard = new Scanner(System.in);

      public boolean validateInput(int leftVal, int rightVal) {
            rightVal = keyboard.nextInt();

            if (rightVal == leftVal) {
                  return true;
            } else {
                  return false;
            }
      }
}