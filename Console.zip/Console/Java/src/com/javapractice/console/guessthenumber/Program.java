package com.javapractice.console.guessthenumber;

import java.io.IOException;

public class Program {
      public static void main(String[] args) {
            (new Program()).run();
      }

      public void run() {
            System.out.print("Guess The Number (Java)\n\nYour Guess: ");

            startGame();
      }

      public void startGame() {
            GameLogic game = new GameLogic();

            boolean isCorrect = game.validateInput(game.secretNumber, game.userInput);
            
            if (isCorrect == true) {
                  try {
                        System.out.print("\nCorrect!\n\nPress any key to continue . . .");

                        System.in.read();
                  } catch (IOException e) {
                        e.printStackTrace();
                  }
            } else {
                  System.out.print("\nIncorrect, try again.\n\nYour Guess: ");

                  startGame();
            }
      }
}
