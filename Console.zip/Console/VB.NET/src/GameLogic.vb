﻿Public Class GameLogic
    Public SecretNumber As Integer = 1114 : Public UserInput As Integer = 0

    Public Function ValidateInput(LeftVal As Integer, RightVal As Integer) As Boolean
        RightVal = Convert.ToInt32(Console.ReadLine())

        If RightVal = LeftVal Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
