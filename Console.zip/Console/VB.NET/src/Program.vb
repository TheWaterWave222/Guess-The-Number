﻿Module Program
    Public Sub Main()
        Console.Write("Guess The Number (VB.NET)" & Environment.NewLine & Environment.NewLine & "Your Guess: ")

        StartGame()
    End Sub

    Sub StartGame()
        Dim Game As New GameLogic

        Dim IsCorrect As Boolean = Game.ValidateInput(Game.SecretNumber, Game.UserInput)

        If IsCorrect = True Then
            Console.Write(Environment.NewLine & "Correct!" & Environment.NewLine & Environment.NewLine & "Press any key to continue . . .")

            Console.ReadKey()
        Else
            Console.Write(Environment.NewLine & "Incorrect, try again." & Environment.NewLine & Environment.NewLine & "Your Guess: ")

            StartGame()
        End If
    End Sub
End Module
